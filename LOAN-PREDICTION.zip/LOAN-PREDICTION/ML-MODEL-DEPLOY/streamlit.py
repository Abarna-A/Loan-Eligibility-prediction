# streamlit_app.py
import streamlit as st
import pickle
import numpy as np

# Load the machine learning model
model = pickle.load(open("model.pkl", "rb"))

# Function to preprocess input data
def preprocess_input(gender, married, dependents, education, employed, credit, area, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term):
    # Convert categorical variables to numerical
    gender = 1 if gender == "Male" else 0
    married = 1 if married == "Yes" else 0
    dependents_1 = 1 if dependents == "1" else 0
    dependents_2 = 1 if dependents == "2" else 0
    dependents_3 = 1 if dependents == "3+" else 0
    not_graduate = 1 if education == "Not Graduate" else 0
    employed_yes = 1 if employed == "Yes" else 0
    semiurban = 1 if area == "Semiurban" else 0
    urban = 1 if area == "Urban" else 0

    # Log-transform numerical features
    ApplicantIncomelog = np.log(ApplicantIncome)
    totalincomelog = np.log(ApplicantIncome + CoapplicantIncome)
    LoanAmountlog = np.log(LoanAmount)
    Loan_Amount_Termlog = np.log(Loan_Amount_Term)

    # Return preprocessed input data
    return [
        credit,
        ApplicantIncomelog,
        LoanAmountlog,
        Loan_Amount_Termlog,
        totalincomelog,
        gender,
        married,
        dependents_1,
        dependents_2,
        dependents_3,
        not_graduate,
        employed_yes,
        semiurban,
        urban,
    ]

# Streamlit UI components
st.title("Loan Prediction")

# User input fields
gender = st.selectbox("Gender", ["Male", "Female"])
married = st.selectbox("Married", ["Yes", "No"])
dependents = st.selectbox("Dependents", ["0", "1", "2", "3+"])
education = st.selectbox("Education", ["Graduate", "Not Graduate"])
employed = st.selectbox("Employment", ["Yes", "No"])
credit = st.number_input("Credit Score")
area = st.selectbox("Property Area", ["Rural", "Semiurban", "Urban"])
ApplicantIncome = st.number_input("Applicant Income")
CoapplicantIncome = st.number_input("Coapplicant Income")
LoanAmount = st.number_input("Loan Amount")
Loan_Amount_Term = st.number_input("Loan Amount Term")

# Predict button
if st.button("Predict"):
    # Preprocess input data
    input_data = preprocess_input(gender, married, dependents, education, employed, credit, area, ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term)

    # Make prediction
    prediction = model.predict([input_data])

    # Display prediction
    if prediction[0] == "N":
        st.write("Loan status: No")
    else:
        st.write("Loan status: Yes")
